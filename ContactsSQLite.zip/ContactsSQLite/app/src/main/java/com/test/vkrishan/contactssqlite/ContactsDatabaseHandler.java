package com.test.vkrishan.contactssqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by vkrishan on 7/18/17.
 */

public class ContactsDatabaseHandler extends SQLiteOpenHelper {

    // DB version
    private static final int DATABASE_VERSION = 1;

    // DB name
    private static final String DATABASE_NAME = "contactsManager";

    // Table name
    private static final String TABLE_NAME = "contacts";

    // Table columns name
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_NUMBER = "number";

    // Constructoer

    public ContactsDatabaseHandler(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);      /// ???????????
    }

    public void onCreate(SQLiteDatabase db){                        /// The parameter is SqliteDatabase
        String CREATE_CONTACTS_TABLE = "CREATE TABLE" + TABLE_NAME + "(" + KEY_ID + "INTEGER PRIMARY KEY," + KEY_NAME + "TEXT," + KEY_NUMBER + "TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        String DROP_CONTACTS_TABLE = "DROP TABLE IF EXISTS" + TABLE_NAME;
        db.execSQL(DROP_CONTACTS_TABLE);

        onCreate(db);
    }


    // CRUD operations (Create, Read, Update, Delete)
    void addContact(Contact contact){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        


    }






}





