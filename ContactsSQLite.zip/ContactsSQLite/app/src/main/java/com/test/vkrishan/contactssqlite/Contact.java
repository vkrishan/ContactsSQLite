package com.test.vkrishan.contactssqlite;

/**
 * Created by vkrishan on 7/18/17.
 */

public class Contact {

    int id;
    String name;
    String number;

    public Contact(){

    }

    public Contact(String name, String number){
        this.name = name;
        this.number = number;
    }

    public Contact(int id, String name, String number){
        this.id = id;
        this.name = name;
        this.number = number;
    }

    // Getter and Setter

    public int getId(){
        return this.id;
    }

    public void setId(int id){
        this.id = id;
    }

    public  String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }

    public  String getNumber(){
        return this.number;
    }

    public void setNumber(String number){
        this.number = number;
    }

}
