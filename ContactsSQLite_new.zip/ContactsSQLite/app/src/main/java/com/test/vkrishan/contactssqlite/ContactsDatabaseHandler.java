package com.test.vkrishan.contactssqlite;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by vkrishan on 7/18/17.
 */

public class ContactsDatabaseHandler extends SQLiteOpenHelper {

    // DB version
    private static final int DATABASE_VERSION = 1;

    // DB name
    private static final String DATABASE_NAME = "contactsManager";

    // Table name
    private static final String TABLE_CONTACT = "contacts";

    // Table columns name
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_NUMBER = "number";

    // Constructoer

    public ContactsDatabaseHandler(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);      /// ???????????
    }

    public void onCreate(SQLiteDatabase db){                        /// New parameter is SqliteDatabase
        String CREATE_CONTACTS_TABLE = "CREATE TABLE" + TABLE_CONTACT + "(" + KEY_ID + "INTEGER PRIMARY KEY," + KEY_NAME + "TEXT," + KEY_NUMBER + "TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){   /// New parameter is SqliteDatabase
        String DROP_CONTACTS_TABLE = "DROP TABLE IF EXISTS" + TABLE_CONTACT;
        db.execSQL(DROP_CONTACTS_TABLE);

        onCreate(db);
    }


    // CRUD operations (Create, Read, Update, Delete)
    public void addContact(Contact contact){

        SQLiteDatabase db = this.getWritableDatabase();      /// New parameter is SqliteDatabase

        ContentValues cv = new ContentValues();             // instantiate content provider
        
        cv.put(KEY_NAME, contact.getName());
        cv.put(KEY_NUMBER, contact.getNumber());

        db.insert(TABLE_CONTACT, null, cv);
        db.close();
    }


    public void deleteContact(Contact contact){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACT, KEY_ID + " = ? ", new String[]{String.valueOf(contact.getId())}); //// String.valueOf
        db.close();
    }


    public int updateContact(Contact contact){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_NAME, contact.getName());
        cv.put(KEY_NUMBER, contact.getNumber());

        return db.update(TABLE_CONTACT, cv, KEY_ID + " = ? ", new String[]{String.valueOf(contact.getId())});
    }

    public Contact getContact(int id){

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_CONTACT, new String[]{KEY_ID,KEY_NAME,KEY_NUMBER}, KEY_ID + " = ?", new String[]{String.valueOf(id)},null,null,null,null);

        if(cursor != null){
            cursor.moveToFirst();
        }

        Contact contact = new Contact(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2));   // ????????????
        return contact;
    }


    public List<Contact> listContact(){

        List<Contact> contactList = new ArrayList<Contact>();

        SQLiteDatabase db = this.getWritableDatabase();

        String selectQuery = " SELECT * FROM " + TABLE_CONTACT;

        Cursor cursor = db.rawQuery(selectQuery, null);     // Cursor

        if(cursor.moveToFirst()){
            do{

                Contact contact = new Contact();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setName(cursor.getString(1));
                contact.setNumber(cursor.getString(2));

                contactList.add(contact);

            } while (cursor.moveToFirst());

        }
        return contactList;
    }

}





